define("epi-cms/contentediting/command/BlockInlineReadyToPublish", [
    "dojo/_base/declare",
    "dojo/when",
    "epi-cms/contentediting/command/SendForReview",
    "epi-cms/contentediting/command/_BlockInlineCommandMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting.inlinecommands.inlinereadytopublish"
], function (
    declare,
    when,
    SendForReview,
    _BlockInlineCommandMixin,
    ContentActionSupport,
    res
) {

    return declare([SendForReview, _BlockInlineCommandMixin], {
        // summary:
        //      Inline command to set a block to be Ready to Publish
        // tags:
        //      internal xproduct

        errorMessageHeading: res.error,

        successMessage: res.success,

        requiredAction: ContentActionSupport.action.CheckIn,

        skippedAction: ContentActionSupport.action.Publish,

        ignoredStatuses: [
            ContentActionSupport.versionStatus.DelayedPublish,
            ContentActionSupport.versionStatus.CheckedIn,
            ContentActionSupport.versionStatus.Published
        ]
    });
});
