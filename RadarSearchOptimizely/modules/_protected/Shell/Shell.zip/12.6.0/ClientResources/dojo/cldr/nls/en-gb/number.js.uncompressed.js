define(
"dojo/cldr/nls/en-gb/number", //begin v1.x content
{
	"currencyFormat": "¤#,##0.00",
	"decimalFormat-short": "000T"
}
//end v1.x content
);